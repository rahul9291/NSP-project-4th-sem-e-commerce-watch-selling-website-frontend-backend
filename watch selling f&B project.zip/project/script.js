﻿const CART_KEY = "watchCart";
const USER_KEY = "watchUser";
const API_BASE = "backend/api.php";

async function apiRequest(action, payload = {}) {
  const response = await fetch(`${API_BASE}?action=${action}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  const data = await response.json();

  if (!response.ok || !data.success) {
    throw new Error(data.message || "Request failed");
  }

  return data.data;
}

function getCart() {
  return JSON.parse(localStorage.getItem(CART_KEY)) || [];
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function addToCart(name, price, image) {
  const cart = getCart();
  const existingItem = cart.find((item) => item.name === name);

  if (existingItem) {
    existingItem.qty += 1;
  } else {
    cart.push({ name, price, image, qty: 1 });
  }

  saveCart(cart);
  alert(name + " added to cart");
  displayCart();
}

function increaseQty(index) {
  const cart = getCart();
  if (!cart[index]) return;

  cart[index].qty += 1;
  saveCart(cart);
  displayCart();
}

function decreaseQty(index) {
  const cart = getCart();
  if (!cart[index]) return;

  if (cart[index].qty > 1) {
    cart[index].qty -= 1;
  } else {
    cart.splice(index, 1);
  }

  saveCart(cart);
  displayCart();
}

function removeItem(index) {
  const cart = getCart();
  cart.splice(index, 1);
  saveCart(cart);
  displayCart();
}

function clearCart() {
  saveCart([]);
  displayCart();
}

async function checkout() {
  const cart = getCart();
  const user = JSON.parse(localStorage.getItem(USER_KEY));

  if (cart.length === 0) {
    alert("Your cart is empty");
    return;
  }

  try {
    const data = await apiRequest("create_order", {
      user_id: user ? user.id : null,
      email: user ? user.email : "",
      items: cart,
    });

    alert("Order placed. Order ID: " + data.order_id);
    clearCart();
  } catch (error) {
    alert("Checkout failed: " + error.message);
  }
}

function displayCart() {
  const cartList = document.getElementById("cart-list");
  const subtotalText = document.getElementById("subtotal");
  const shippingText = document.getElementById("shipping");
  const totalText = document.getElementById("total");
  const cartCount = document.getElementById("cart-count");
  const cart = getCart();
  const itemCount = cart.reduce((count, item) => count + item.qty, 0);

  if (cartCount) cartCount.textContent = itemCount;
  if (!cartList) return;

  if (cart.length === 0) {
    cartList.innerHTML = `
      <div class="empty-cart">
        <h2>Your cart is empty</h2>
        <p>Add your favourite watches from the home page.</p>
        <a href="index.html">Continue Shopping</a>
      </div>
    `;
  } else {
    cartList.innerHTML = cart.map((item, index) => {
      const itemTotal = item.price * item.qty;

      return `
        <article class="cart-item">
          <img src="${item.image}" alt="${item.name}">
          <div class="cart-details">
            <h3>${item.name}</h3>
            <p>Rs. ${item.price}</p>
            <div class="qty-box">
              <button type="button" onclick="decreaseQty(${index})">-</button>
              <span>${item.qty}</span>
              <button type="button" onclick="increaseQty(${index})">+</button>
            </div>
          </div>
          <div class="cart-actions">
            <strong>Rs. ${itemTotal}</strong>
            <button type="button" onclick="removeItem(${index})">Remove</button>
          </div>
        </article>
      `;
    }).join("");
  }

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const shipping = cart.length > 0 ? 199 : 0;
  const total = subtotal + shipping;

  if (subtotalText) subtotalText.textContent = "Rs. " + subtotal;
  if (shippingText) shippingText.textContent = "Rs. " + shipping;
  if (totalText) totalText.textContent = "Rs. " + total;
}

function setupLoginPage() {
  const loginForm = document.getElementById("login-form");
  const signupForm = document.getElementById("signup-form");
  const showSignup = document.getElementById("show-signup");
  const showLogin = document.getElementById("show-login");
  const title = document.getElementById("form-title");

  if (!loginForm || !signupForm || !showSignup || !showLogin || !title) return;

  showSignup.addEventListener("click", (event) => {
    event.preventDefault();
    loginForm.classList.remove("active");
    signupForm.classList.add("active");
    title.textContent = "Create Account";
  });

  showLogin.addEventListener("click", (event) => {
    event.preventDefault();
    signupForm.classList.remove("active");
    loginForm.classList.add("active");
    title.textContent = "Login";
  });

  signupForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const name = document.getElementById("signup-name").value.trim();
    const email = document.getElementById("signup-email").value.trim();
    const password = document.getElementById("signup-password").value;

    try {
      const data = await apiRequest("signup", { name, email, password });

      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      alert("Account created successfully");
      signupForm.classList.remove("active");
      loginForm.classList.add("active");
      title.textContent = "Login";
    } catch (error) {
      alert("Signup failed: " + error.message);
    }
  });

  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const email = document.getElementById("login-email").value.trim();
    const password = document.getElementById("login-password").value;

    try {
      const data = await apiRequest("login", { email, password });

      localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      alert("Login successful");
      window.location.href = "index.html";
    } catch (error) {
      alert("Login failed: " + error.message);
    }
  });
}

window.addToCart = addToCart;
window.increaseQty = increaseQty;
window.decreaseQty = decreaseQty;
window.removeItem = removeItem;
window.clearCart = clearCart;
window.checkout = checkout;

document.addEventListener("DOMContentLoaded", () => {
  displayCart();
  setupLoginPage();
});
