# XAMPP Backend Setup

1. Copy this full project folder into `C:\xampp\htdocs\project`.
2. Start Apache and MySQL from XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`.
4. Import `backend/schema.sql`.
5. Open `http://localhost/project/index.html`.

Default database settings are in `backend/config.php`:

- Host: `localhost`
- User: `root`
- Password: empty
- Database: `watch_store`

API test URL:

`http://localhost/project/backend/api.php?action=health`
