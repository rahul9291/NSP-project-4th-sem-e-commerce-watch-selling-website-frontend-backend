<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit;
}

require_once __DIR__ . "/config.php";

$action = $_GET["action"] ?? "";
$input = json_decode(file_get_contents("php://input"), true);

if (!is_array($input)) {
    $input = [];
}

function send_response($success, $message, $data = [], $status = 200) {
    http_response_code($status);
    echo json_encode([
        "success" => $success,
        "message" => $message,
        "data" => $data
    ]);
    exit;
}

function required_value($input, $key) {
    return trim($input[$key] ?? "");
}

if ($action === "health") {
    send_response(true, "Backend is running");
}

if ($action === "signup") {
    $name = required_value($input, "name");
    $email = strtolower(required_value($input, "email"));
    $plainPassword = $input["password"] ?? "";

    if ($name === "" || $email === "" || $plainPassword === "") {
        send_response(false, "Name, email and password are required", [], 400);
    }

    $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $existing = $check->get_result();

    if ($existing->num_rows > 0) {
        send_response(false, "Account already exists", [], 409);
    }

    $hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $hashedPassword);

    if (!$stmt->execute()) {
        send_response(false, "Signup failed", [], 500);
    }

    send_response(true, "Account created", [
        "user" => [
            "id" => $stmt->insert_id,
            "name" => $name,
            "email" => $email
        ]
    ], 201);
}

if ($action === "login") {
    $email = strtolower(required_value($input, "email"));
    $plainPassword = $input["password"] ?? "";

    if ($email === "" || $plainPassword === "") {
        send_response(false, "Email and password are required", [], 400);
    }

    $stmt = $conn->prepare("SELECT id, name, email, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        send_response(false, "Wrong email or password", [], 401);
    }

    $user = $result->fetch_assoc();

    if (!password_verify($plainPassword, $user["password"])) {
        send_response(false, "Wrong email or password", [], 401);
    }

    send_response(true, "Login successful", [
        "user" => [
            "id" => (int) $user["id"],
            "name" => $user["name"],
            "email" => $user["email"]
        ]
    ]);
}

if ($action === "create_order") {
    $userId = isset($input["user_id"]) ? (int) $input["user_id"] : null;
    $customerEmail = strtolower(required_value($input, "email"));
    $items = $input["items"] ?? [];

    if (!is_array($items) || count($items) === 0) {
        send_response(false, "Cart is empty", [], 400);
    }

    $subtotal = 0;
    $cleanItems = [];

    foreach ($items as $item) {
        $name = trim($item["name"] ?? "");
        $image = trim($item["image"] ?? "");
        $price = (float) ($item["price"] ?? 0);
        $qty = (int) ($item["qty"] ?? 0);

        if ($name === "" || $price <= 0 || $qty <= 0) {
            continue;
        }

        $subtotal += $price * $qty;
        $cleanItems[] = [
            "name" => $name,
            "image" => $image,
            "price" => $price,
            "qty" => $qty
        ];
    }

    if (count($cleanItems) === 0) {
        send_response(false, "Cart items are invalid", [], 400);
    }

    $shipping = 199;
    $total = $subtotal + $shipping;

    $conn->begin_transaction();

    try {
        $orderStmt = $conn->prepare(
            "INSERT INTO orders (user_id, customer_email, subtotal, shipping, total) VALUES (?, ?, ?, ?, ?)"
        );
        $orderStmt->bind_param("isddd", $userId, $customerEmail, $subtotal, $shipping, $total);
        $orderStmt->execute();
        $orderId = $orderStmt->insert_id;

        $itemStmt = $conn->prepare(
            "INSERT INTO order_items (order_id, product_name, product_image, price, quantity) VALUES (?, ?, ?, ?, ?)"
        );

        foreach ($cleanItems as $item) {
            $productName = $item["name"];
            $productImage = $item["image"];
            $price = $item["price"];
            $quantity = $item["qty"];

            $itemStmt->bind_param(
                "issdi",
                $orderId,
                $productName,
                $productImage,
                $price,
                $quantity
            );
            $itemStmt->execute();
        }

        $conn->commit();

        send_response(true, "Order placed", [
            "order_id" => $orderId,
            "subtotal" => $subtotal,
            "shipping" => $shipping,
            "total" => $total
        ], 201);
    } catch (Throwable $error) {
        $conn->rollback();
        send_response(false, "Order failed", [], 500);
    }
}

if ($action === "orders") {
    $result = $conn->query(
        "SELECT id, customer_email, subtotal, shipping, total, created_at FROM orders ORDER BY id DESC"
    );

    $orders = [];

    while ($row = $result->fetch_assoc()) {
        $orders[] = $row;
    }

    send_response(true, "Orders loaded", ["orders" => $orders]);
}

send_response(false, "Invalid API action", [], 404);
?>
